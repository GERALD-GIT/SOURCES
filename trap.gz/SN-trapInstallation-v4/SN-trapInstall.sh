#!/bin/bash

echo "APT UPDATE"
apt-get update

echo "Installation of the snmptrapd package"
if apt-get install snmptrapd ; then
        echo "snmpttrapd installation succeeded"
else
        echo "snmpttrapd installation failed"
        exit
fi

echo "Installation of the SNMPTT package"
if apt-get install snmptt ; then
	echo "snmptt installation succeeded"
else
	echo "snmptt installation failed"
	exit
fi

echo "Setting snmptrapd autostart"
if systemctl enable snmptrapd ; then
        echo "Setting snmptrapd autostart succeeded"
else
        echo "Setting snmptrapd autostar failed"
	exit
fi

echo "Setting snmptt autostart"
if systemctl enable snmptt ; then
        echo "Setting snmptt autostart succeeded"
else
        echo "Setting snmptt autostar failed"
        exit
fi


echo "Copy of the configuration file and configuration of the trapfile rotation"
if cp snmptt.ini /etc/snmp/ && cp snmptt /etc/logrotate.d/ ; then
	echo "Copy and configuration succeeded"
else
	echo "Copy of snmptt.ini or snmptt rotation failed"
	exit
fi

mkdir /var/log/snmptt/positions
chown nagios:nagios /var/log/snmptt/positions
mkdir /etc/snmp/trapConf

echo "Adding the snmp trap rules in iptables and restart the service"

pattern1='PORT_SNMP="161"'
text1='PORT_TRAP_SNMP="162"'

pattern2="iptables -A INPUT -p udp --dport \$PORT_SNMP -j ACCEPT"
text2="## Acceptation des connexions SNMP Trap \niptables -A INPUT -p udp -i ens160 --dport \$PORT_TRAP_SNMP -j ACCEPT"

if sed -i "/$pattern1/ a $text1" /etc/init.d/iptables.sh ; then
        if sed -i "/$pattern2/ a $text2" /etc/init.d/iptables.sh ; then
                if /etc/init.d/iptables.sh ; then
                        echo "Firewall configuration succeeded"
                else
                        echo "Failed to restart iptables service"
			exit
                fi
        else
                echo "Firewall configuration failed"
                exit
        fi
else
        echo "Firewall configuration failed"
        exit
fi

if cp snmptrapd.conf /etc/snmp/snmptrapd.conf ; then
	echo "Copy /etc/snmp/snmptrapd.conf succeeded"
else
	echo "Copy /etc/snmp/snmptrapd.conf failed"
	exit
fi

echo "Quelle est la communauté utilisée pour les traps ? :"
read community

while [[ "$community" == '' ]]
do
  echo "Quelle est la communauté utilisée pour les traps ? :"
  read community
done

if sed -i "s/myComm/$community/g" /etc/snmp/snmptrapd.conf ; then
	echo "Community setting succeeded : $community"
else
	echo "Community setting failed"
	exit
fi

if systemctl restart snmptrapd ; then
	echo "Restart snmptrapd succeeded"
else
	echo "Restart snmptrapd failed"
	exit
fi

echo "Installation of SNMPTRAP succeeded, please create trap definition file"
